import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { SCENES, COLORS } from "./config";
import { IntroScene } from "./scenes/IntroScene";
import { TextDemoScene } from "./scenes/TextDemoScene";
import { CodeDemoScene } from "./scenes/CodeDemoScene";
import { CryptoDemoScene } from "./scenes/CryptoDemoScene";
import { OutroScene } from "./scenes/OutroScene";
import { ProgressBar } from "./components";

export const DemoShowcase: React.FC = () => {
  return (
    <AbsoluteFill style={{ backgroundColor: COLORS.background }}>
      <Sequence from={SCENES.intro.from} durationInFrames={SCENES.intro.duration}>
        <IntroScene />
      </Sequence>

      <Sequence from={SCENES.text.from} durationInFrames={SCENES.text.duration}>
        <TextDemoScene />
      </Sequence>

      <Sequence from={SCENES.code.from} durationInFrames={SCENES.code.duration}>
        <CodeDemoScene />
      </Sequence>

      <Sequence from={SCENES.crypto.from} durationInFrames={SCENES.crypto.duration}>
        <CryptoDemoScene />
      </Sequence>

      <Sequence from={SCENES.outro.from} durationInFrames={SCENES.outro.duration}>
        <OutroScene />
      </Sequence>

      <ProgressBar
        height={4}
        showTime
        gradientColors={[COLORS.primary, COLORS.accent]}
      />
    </AbsoluteFill>
  );
};
