export const FPS = 30;
export const DEMO_DURATION = 900; // 30 seconds

export const SCENES = {
  intro: { from: 0, duration: 150 },
  text: { from: 150, duration: 150 },
  code: { from: 300, duration: 180 },
  crypto: { from: 480, duration: 180 },
  outro: { from: 660, duration: 240 },
} as const;

// 🌿 SOLARPUNK COLOR PALETTE
export const COLORS = {
  // Backgrounds - deep forest night
  background: "#0a1410",
  backgroundLight: "#112920",
  backgroundGlow: "#0d1f1a",
  
  // Primary nature tones
  leaf: "#22c55e",           // Vibrant leaf
  vine: "#16a34a",           // Deep vine
  moss: "#15803d",           // Forest moss
  fern: "#4ade80",           // Bright fern
  
  // Solar/light tones
  sun: "#f59e0b",            // Golden sun
  amber: "#fbbf24",          // Warm amber
  honey: "#fcd34d",          // Light honey
  
  // Water/tech tones
  teal: "#14b8a6",           // Clean water
  cyan: "#2dd4bf",           // Tech glow
  aqua: "#5eead4",           // Bright aqua
  
  // Earth tones
  coral: "#f87171",          // Soft coral
  terracotta: "#fb923c",     // Earth orange
  
  // Text
  text: "#ecfdf5",           // Mint white
  textMuted: "#6ee7b7",      // Soft green
  textDark: "#365314",       // Dark moss
  
  // Semantic
  primary: "#22c55e",
  secondary: "#14b8a6",
  accent: "#f59e0b",
  success: "#84cc16",
  warning: "#fbbf24",
  error: "#f87171",
  
  // Legacy compatibility
  html: "#22c55e",
  crypto: "#2dd4bf",
} as const;
