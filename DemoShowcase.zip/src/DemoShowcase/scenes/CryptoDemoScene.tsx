import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { COLORS } from "../config";
import { SceneHeader, SpeakingHead, Card, Timeline, ComparisonTable, RotatingObject } from "../components";

const ecoTimeline = [
  { id: "1", title: "Seed", description: "Plant the idea", icon: "🌱", color: COLORS.leaf },
  { id: "2", title: "Grow", description: "Nurture with care", icon: "🌿", color: COLORS.fern },
  { id: "3", title: "Bloom", description: "Energy harvest", icon: "🌻", color: COLORS.sun },
  { id: "4", title: "Share", description: "Community power", icon: "🤝", color: COLORS.teal },
];

const comparisonData = {
  columns: [
    { key: "aspect", header: "Aspect" },
    { key: "old", header: "🏭 Old World" },
    { key: "new", header: "🌿 Solarpunk" },
  ],
  rows: [
    { aspect: "Energy", old: "Fossil fuels", new: "☀️ Solar + Wind" },
    { aspect: "Food", old: "Monoculture", new: "🌱 Permaculture" },
    { aspect: "Cities", old: "Concrete jungle", new: "🌳 Garden cities" },
    { aspect: "Tech", old: "Extractive", new: "🔄 Regenerative" },
  ],
};

export const CryptoDemoScene: React.FC = () => {
  const frame = useCurrentFrame();

  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(ellipse at 30% 70%, ${COLORS.leaf}10 0%, transparent 50%),
                     radial-gradient(ellipse at 70% 30%, ${COLORS.sun}08 0%, transparent 50%),
                     linear-gradient(135deg, ${COLORS.background} 0%, ${COLORS.backgroundLight} 100%)`,
        padding: 60,
      }}
    >
      <SceneHeader
        sceneNumber={3}
        totalScenes={4}
        title="Community"
        keyword="HARMONY"
        startFrame={0}
      />

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1.5fr",
          gap: 40,
          marginTop: 100,
          height: "calc(100% - 180px)",
        }}
      >
        {/* Left: Characters */}
        <div style={{ display: "flex", flexDirection: "column", gap: 30 }}>
          <div style={{ display: "flex", justifyContent: "space-around" }}>
            <SpeakingHead
              name="Terra"
              emoji="🧑‍🌾"
              color={COLORS.leaf}
              startFrame={20}
              speaking={frame > 40 && frame < 100}
              message="Let's grow together!"
            />
            <SpeakingHead
              name="Sol"
              emoji="🧑‍🔬"
              color={COLORS.sun}
              startFrame={30}
              speaking={frame > 100}
              message="Clean energy for all!"
            />
          </div>

          <div style={{ display: "flex", justifyContent: "center" }}>
            <RotatingObject
              size={70}
              shape="hexagon"
              color={COLORS.leaf}
              borderColor={COLORS.fern}
              rotationSpeed={0.3}
            />
          </div>

          <Timeline
            items={ecoTimeline}
            startFrame={50}
            itemDelay={18}
            direction="vertical"
          />
        </div>

        {/* Right: Table */}
        <Card
          title="Future vs Past"
          icon="⚖️"
          startFrame={40}
          bordered
          borderColor={COLORS.leaf}
        >
          <ComparisonTable
            columns={comparisonData.columns}
            rows={comparisonData.rows}
            startFrame={60}
            rowDelay={14}
            highlightRow={3}
          />
        </Card>
      </div>
    </AbsoluteFill>
  );
};
