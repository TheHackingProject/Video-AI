import React from "react";
import { AbsoluteFill } from "remotion";
import { COLORS } from "../config";
import { Typewriter, WordByWord, TextReveal, SceneHeader, Card } from "../components";

export const TextDemoScene: React.FC = () => {
  return (
    <AbsoluteFill
      style={{
        background: `linear-gradient(160deg, ${COLORS.background} 0%, ${COLORS.backgroundLight} 50%, ${COLORS.background} 100%)`,
        padding: 60,
      }}
    >
      {/* Subtle vine pattern overlay */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          opacity: 0.03,
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 0 Q45 15 30 30 Q15 45 30 60' fill='none' stroke='%2322c55e' stroke-width='1'/%3E%3C/svg%3E")`,
        }}
      />

      <SceneHeader
        sceneNumber={1}
        totalScenes={4}
        title="Text Components"
        keyword="GROWTH"
        startFrame={0}
      />

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 40,
          marginTop: 120,
          height: "calc(100% - 200px)",
        }}
      >
        <Card title="Typewriter" icon="🌱" startFrame={20} bordered borderColor={COLORS.leaf}>
          <div style={{ padding: 20 }}>
            <Typewriter
              text="Biomimicry: nature's patterns inspire sustainable innovation..."
              startFrame={30}
              charsPerSecond={22}
              fontSize={22}
              color={COLORS.text}
              cursorColor={COLORS.leaf}
            />
          </div>
        </Card>

        <Card title="Word Flow" icon="🍃" startFrame={30} bordered borderColor={COLORS.teal}>
          <div style={{ padding: 20 }}>
            <WordByWord
              text="Technology rooted in ecological harmony"
              startFrame={40}
              wordDelay={10}
              fontSize={22}
              highlightColor={COLORS.sun}
            />
          </div>
        </Card>

        <Card title="Reveal" icon="☀️" startFrame={40} style={{ gridColumn: "span 2" }} bordered borderColor={COLORS.sun}>
          <div
            style={{
              padding: 30,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <TextReveal
              text="🌿 GROW → ADAPT → THRIVE 🌿"
              startFrame={50}
              direction="center"
              fontSize={38}
              color={COLORS.leaf}
            />
          </div>
        </Card>
      </div>
    </AbsoluteFill>
  );
};
