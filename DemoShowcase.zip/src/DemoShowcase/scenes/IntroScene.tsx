import React from "react";
import { AbsoluteFill } from "remotion";
import { COLORS } from "../config";
import { FloatingText, ParticleField, GlitchText, Badge } from "../components";

export const IntroScene: React.FC = () => {
  return (
    <AbsoluteFill
      style={{
        justifyContent: "center",
        alignItems: "center",
        background: `radial-gradient(ellipse at center, ${COLORS.backgroundGlow} 0%, ${COLORS.background} 70%, #000 100%)`,
      }}
    >
      {/* Organic floating particles - leaves & light */}
      <ParticleField
        count={50}
        colors={[COLORS.leaf, COLORS.fern, COLORS.sun, COLORS.teal]}
        speed={0.25}
      />

      {/* Vine-like decorative lines */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: `
            linear-gradient(135deg, transparent 45%, ${COLORS.leaf}08 50%, transparent 55%),
            linear-gradient(225deg, transparent 45%, ${COLORS.teal}08 50%, transparent 55%)
          `,
        }}
      />

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 30,
          zIndex: 10,
        }}
      >
        {/* Sun glow behind title */}
        <div
          style={{
            position: "absolute",
            width: 400,
            height: 400,
            borderRadius: "50%",
            background: `radial-gradient(circle, ${COLORS.sun}15 0%, transparent 70%)`,
            filter: "blur(40px)",
          }}
        />

        <FloatingText
          text="🌿 Solarpunk"
          startFrame={10}
          floatAmplitude={6}
          fontSize={82}
          color={COLORS.text}
          shadowColor={COLORS.leaf}
        />

        <GlitchText
          text="SUSTAINABLE TECH × NATURE"
          startFrame={40}
          duration={40}
          intensity={0.5}
          fontSize={26}
          color={COLORS.textMuted}
          glitchColor1={COLORS.leaf}
          glitchColor2={COLORS.sun}
        />

        <div style={{ display: "flex", gap: 16, marginTop: 20 }}>
          <Badge text="Organic" variant="success" icon="🌱" startFrame={70} />
          <Badge text="Solar" variant="warning" icon="☀️" startFrame={80} />
          <Badge text="Future" variant="info" icon="🔮" startFrame={90} />
        </div>
      </div>
    </AbsoluteFill>
  );
};
