import React from "react";
import { AbsoluteFill } from "remotion";
import { COLORS } from "../config";
import { CodeBlock, Terminal, SceneHeader, FlowChart } from "../components";

const ecoCode = `// 🌱 Sustainable Energy Grid
import { SolarPanel, WindTurbine } from '@eco/energy';

async function harvestEnergy() {
  const sun = await SolarPanel.capture();
  const wind = await WindTurbine.generate();
  
  return {
    clean: sun + wind,
    stored: Battery.save(sun + wind),
    shared: Grid.distribute()
  };
}

// 🌿 Zero waste, infinite growth`;

const terminalLines = [
  { type: "command" as const, text: "eco init sustainable-city" },
  { type: "output" as const, text: "🌱 Initializing green infrastructure...", delay: 20 },
  { type: "success" as const, text: "✓ Solar grid: ONLINE", delay: 12 },
  { type: "success" as const, text: "✓ Vertical farms: ACTIVE", delay: 10 },
  { type: "success" as const, text: "✓ Water recycling: 100%", delay: 10 },
  { type: "command" as const, text: "eco status --harmony", delay: 20 },
  { type: "output" as const, text: "🌍 Ecosystem balance: OPTIMAL", delay: 15 },
];

export const CodeDemoScene: React.FC = () => {
  return (
    <AbsoluteFill
      style={{
        background: `linear-gradient(180deg, ${COLORS.background} 0%, ${COLORS.backgroundLight} 100%)`,
        padding: 60,
      }}
    >
      <SceneHeader
        sceneNumber={2}
        totalScenes={4}
        title="Code Components"
        keyword="BUILD"
        startFrame={0}
      />

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 30,
          marginTop: 100,
          height: "calc(100% - 180px)",
        }}
      >
        <CodeBlock
          code={ecoCode}
          title="sustainable.ts"
          startFrame={20}
          highlightLines={[6, 7, 8, 9, 10]}
          fontSize={15}
          style={{ height: "fit-content" }}
        />

        <div style={{ display: "flex", flexDirection: "column", gap: 30 }}>
          <Terminal
            lines={terminalLines}
            title="eco-terminal"
            startFrame={40}
            typeSpeed={1.8}
            fontSize={14}
            prompt="🌿 "
            style={{ flex: 1 }}
          />

          <FlowChart
            nodes={[
              { id: "1", label: "Capture", icon: "☀️", color: COLORS.sun },
              { id: "2", label: "Store", icon: "🔋", color: COLORS.teal },
              { id: "3", label: "Share", icon: "🌐", color: COLORS.leaf },
            ]}
            startFrame={90}
            nodeDelay={15}
            direction="horizontal"
          />
        </div>
      </div>
    </AbsoluteFill>
  );
};
