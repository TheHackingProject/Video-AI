import React from "react";
import { AbsoluteFill, useCurrentFrame, spring, useVideoConfig } from "remotion";
import { COLORS } from "../config";
import { FloatingText, ParticleField, Waveform, Spectrum, Button, Tree, Badge } from "../components";

const componentTree = {
  id: "root",
  label: "🌳 solarpunk-lib",
  color: COLORS.leaf,
  children: [
    { id: "nature", label: "🌿 nature/", color: COLORS.fern },
    { id: "energy", label: "☀️ energy/", color: COLORS.sun },
    { id: "tech", label: "💧 tech/", color: COLORS.teal },
    { id: "community", label: "🤝 community/", color: COLORS.coral },
  ],
};

export const OutroScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const fadeIn = spring({ frame, fps, config: { damping: 200 } });

  return (
    <AbsoluteFill
      style={{
        background: `
          radial-gradient(ellipse at 50% 100%, ${COLORS.leaf}15 0%, transparent 50%),
          radial-gradient(ellipse at 50% 0%, ${COLORS.sun}10 0%, transparent 40%),
          linear-gradient(180deg, ${COLORS.background} 0%, ${COLORS.backgroundLight} 100%)
        `,
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      {/* Organic particles */}
      <ParticleField
        count={35}
        colors={[COLORS.leaf, COLORS.fern, COLORS.sun, COLORS.teal, COLORS.amber]}
        speed={0.2}
      />

      {/* Golden sun glow */}
      <div
        style={{
          position: "absolute",
          top: -100,
          width: 600,
          height: 300,
          borderRadius: "50%",
          background: `radial-gradient(ellipse, ${COLORS.sun}20 0%, transparent 70%)`,
          filter: "blur(60px)",
        }}
      />

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 35,
          zIndex: 10,
          opacity: fadeIn,
        }}
      >
        <FloatingText
          text="🌍 22 Components"
          startFrame={0}
          fontSize={58}
          color={COLORS.text}
          shadowColor={COLORS.leaf}
        />

        <div style={{ display: "flex", gap: 14, flexWrap: "wrap", justifyContent: "center" }}>
          <Badge text="Organic" variant="success" icon="🌱" startFrame={30} />
          <Badge text="Solar" variant="warning" icon="☀️" startFrame={38} />
          <Badge text="Clean" variant="info" icon="💧" startFrame={46} />
          <Badge text="Community" variant="error" icon="🤝" startFrame={54} />
          <Badge text="Future" variant="default" icon="🔮" startFrame={62} />
        </div>

        <Tree root={componentTree} startFrame={70} expandDelay={18} />

        <div style={{ display: "flex", gap: 25, marginTop: 15 }}>
          <Waveform
            width={180}
            height={35}
            bars={18}
            color={COLORS.leaf}
            speed={0.12}
          />
          <Spectrum
            width={180}
            height={35}
            bars={14}
            gradientColors={[COLORS.leaf, COLORS.sun]}
            speed={0.1}
          />
        </div>

        <div style={{ display: "flex", gap: 20, marginTop: 15 }}>
          <Button
            text="Grow with us"
            variant="primary"
            icon="🌱"
            startFrame={120}
            hover
          />
          <Button
            text="Open Source"
            variant="outline"
            icon="🌍"
            startFrame={130}
          />
        </div>
      </div>
    </AbsoluteFill>
  );
};
