import { interpolate, spring, SpringConfig } from "remotion";

export const springConfigs = {
  smooth: { damping: 200 } as SpringConfig,
  bouncy: { damping: 8, stiffness: 100 } as SpringConfig,
  snappy: { damping: 20, stiffness: 200 } as SpringConfig,
  gentle: { damping: 30, stiffness: 80 } as SpringConfig,
};

export const fadeIn = (frame: number, delay: number = 0, duration: number = 20): number => {
  return interpolate(frame, [delay, delay + duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
};

export const slideIn = (
  frame: number,
  fps: number,
  delay: number = 0,
  direction: "left" | "right" | "top" | "bottom" = "bottom",
  distance: number = 50,
  config: SpringConfig = springConfigs.smooth
): { transform: string; opacity: number } => {
  const progress = spring({ frame: frame - delay, fps, config });
  const directionMap = {
    left: `translateX(${interpolate(progress, [0, 1], [-distance, 0])}px)`,
    right: `translateX(${interpolate(progress, [0, 1], [distance, 0])}px)`,
    top: `translateY(${interpolate(progress, [0, 1], [-distance, 0])}px)`,
    bottom: `translateY(${interpolate(progress, [0, 1], [distance, 0])}px)`,
  };
  return { transform: directionMap[direction], opacity: progress };
};

export const staggerDelay = (index: number, baseDelay: number = 0, stagger: number = 5): number => {
  return baseDelay + index * stagger;
};
