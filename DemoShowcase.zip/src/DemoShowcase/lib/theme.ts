export interface Theme {
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    success: string;
    warning: string;
    error: string;
    background: string;
    backgroundLight: string;
    text: string;
    textMuted: string;
    textDark: string;
    code: {
      background: string;
      text: string;
      keyword: string;
      string: string;
      comment: string;
      function: string;
      variable: string;
    };
  };
  fonts: {
    title: string;
    body: string;
    code: string;
  };
  fontSizes: {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    xxl: number;
    display: number;
  };
  spacing: {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    xxl: number;
  };
  borderRadius: {
    sm: number;
    md: number;
    lg: number;
    xl: number;
    full: number;
  };
}

// 🌿 SOLARPUNK DARK THEME
// Nature meets sustainable tech - lush greens, golden sun, organic curves
export const defaultTheme: Theme = {
  colors: {
    // Core palette - organic nature + golden light
    primary: "#22c55e",       // Vibrant leaf green
    secondary: "#14b8a6",     // Teal - clean water/tech
    accent: "#f59e0b",        // Solar amber/gold
    success: "#84cc16",       // Lime - growth
    warning: "#fbbf24",       // Warm gold
    error: "#f87171",         // Soft coral (not aggressive red)
    
    // Dark forest backgrounds
    background: "#0a1410",    // Deep forest night
    backgroundLight: "#112920", // Mossy dark
    
    // Text - warm and organic
    text: "#ecfdf5",          // Soft mint white
    textMuted: "#6ee7b7",     // Faded green
    textDark: "#365314",      // Dark moss
    
    // Code - nature-inspired syntax
    code: {
      background: "#071311",  // Deepest forest
      text: "#d1fae5",        // Pale green
      keyword: "#22c55e",     // Leaf green
      string: "#fcd34d",      // Sunlight yellow
      comment: "#4ade80",     // Faded vine
      function: "#2dd4bf",    // Teal bloom
      variable: "#f59e0b",    // Amber
    },
  },
  fonts: {
    title: "'Poppins', sans-serif",
    body: "'Inter', sans-serif",
    code: "'JetBrains Mono', monospace",
  },
  fontSizes: {
    xs: 14,
    sm: 16,
    md: 20,
    lg: 24,
    xl: 32,
    xxl: 48,
    display: 72,
  },
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },
  borderRadius: {
    sm: 6,
    md: 12,
    lg: 16,
    xl: 24,
    full: 9999,
  },
};
