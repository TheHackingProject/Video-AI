# DemoShowcase - Remotion Components Demo

A **fully self-contained** Remotion composition showcasing 22 reusable animated components for video production.

## Quick Start

1. Copy the entire `DemoShowcase/` folder into your Remotion project's `src/` directory

2. Register the composition in your `Root.tsx`:

```tsx
import { DemoShowcase, DEMO_DURATION } from "./DemoShowcase";

// Inside your RemotionRoot component:
<Composition
  id="DemoShowcase"
  component={DemoShowcase}
  durationInFrames={DEMO_DURATION}
  fps={30}
  width={1920}
  height={1080}
/>
```

3. Run the dev server:

```bash
npm run dev
# Open http://localhost:3000/DemoShowcase
```

## Render

```bash
# Full video (MP4)
npx remotion render DemoShowcase output.mp4

# Single frame (PNG)
npx remotion still DemoShowcase --frame=300 --output=preview.png

# GIF
npx remotion render DemoShowcase output.gif --codec=gif
```

## Structure

```
DemoShowcase/
├── index.ts              # Main export
├── config.ts             # Duration, colors, scene timings
├── DemoShowcase.tsx      # Main composition
├── README.md
│
├── lib/                  # Utilities
│   ├── theme.ts          # Configurable theme (colors, fonts, spacing)
│   └── animations.ts     # Spring configs, fadeIn, slideIn helpers
│
├── components/           # 22 reusable components
│   ├── Typewriter.tsx    # Typing animation
│   ├── WordByWord.tsx    # TikTok-style word reveal
│   ├── TextReveal.tsx    # Clip-path text reveal
│   ├── GlitchText.tsx    # Cyberpunk glitch effect
│   ├── FloatingText.tsx  # 3D floating text with shadow
│   ├── CodeBlock.tsx     # Syntax-highlighted code
│   ├── Terminal.tsx      # Animated terminal with commands
│   ├── ProgressBar.tsx   # Video progress indicator
│   ├── SceneHeader.tsx   # Scene number + keyword badge
│   ├── Badge.tsx         # Animated badges (success, error, etc.)
│   ├── Button.tsx        # CTA buttons with hover effect
│   ├── Card.tsx          # Content cards
│   ├── FlowChart.tsx     # Animated flow diagram
│   ├── Timeline.tsx      # Vertical/horizontal timeline
│   ├── ComparisonTable.tsx # Animated comparison table
│   ├── Tree.tsx          # Expandable tree diagram
│   ├── SpeakingHead.tsx  # Avatar with speech bubble
│   ├── Waveform.tsx      # Audio waveform visualization
│   ├── Spectrum.tsx      # Frequency spectrum bars
│   ├── RotatingObject.tsx # CSS 3D rotating shape
│   └── ParticleField.tsx # Floating particles background
│
└── scenes/               # Demo scenes
    ├── IntroScene.tsx    # Title + particles + glitch
    ├── TextDemoScene.tsx # Text components showcase
    ├── CodeDemoScene.tsx # Code + terminal + flowchart
    ├── CryptoDemoScene.tsx # Crypto theme with avatars
    └── OutroScene.tsx    # Summary with all components
```

## Customization

### Theme

Edit `lib/theme.ts` to customize:

```ts
export const defaultTheme = {
  colors: {
    primary: "#4361ee",    // Change main accent color
    secondary: "#7209b7",
    accent: "#f72585",
    // ...
  },
  fonts: {
    title: "'Poppins', sans-serif",
    body: "'Inter', sans-serif",
    code: "'JetBrains Mono', monospace",
  },
  // ...
};
```

### Scene Timings

Edit `config.ts` to adjust durations:

```ts
export const SCENES = {
  intro: { from: 0, duration: 150 },      // 5 seconds at 30fps
  text: { from: 150, duration: 150 },
  code: { from: 300, duration: 180 },
  crypto: { from: 480, duration: 180 },
  outro: { from: 660, duration: 240 },
};
```

## Component Usage Examples

### Typewriter

```tsx
<Typewriter
  text="Hello World!"
  startFrame={0}
  charsPerSecond={25}
  showCursor={true}
/>
```

### CodeBlock

```tsx
<CodeBlock
  code={`const x = 1;\nconsole.log(x);`}
  title="example.js"
  highlightLines={[2]}
  startFrame={10}
/>
```

### Terminal

```tsx
<Terminal
  lines={[
    { type: "command", text: "npm install" },
    { type: "success", text: "Done!", delay: 20 },
  ]}
  startFrame={0}
/>
```

### SpeakingHead

```tsx
<SpeakingHead
  name="Alice"
  emoji="👩"
  color="#58a6ff"
  speaking={frame > 30}
  message="Hello!"
/>
```

### FlowChart

```tsx
<FlowChart
  nodes={[
    { id: "1", label: "Start", icon: "🚀" },
    { id: "2", label: "Process", icon: "⚙️" },
    { id: "3", label: "End", icon: "✅" },
  ]}
  direction="horizontal"
  startFrame={0}
/>
```

## Dependencies

- `remotion` (core)
- `react` (peer dependency)

No additional packages required. All components use Remotion's built-in utilities (`useCurrentFrame`, `spring`, `interpolate`, `random`).

## License

MIT - Use freely in your projects.
