import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { defaultTheme, Theme } from "../lib/theme";

interface TypewriterProps {
  text: string;
  startFrame?: number;
  charsPerSecond?: number;
  showCursor?: boolean;
  cursorChar?: string;
  fontSize?: number;
  fontFamily?: string;
  color?: string;
  cursorColor?: string;
  theme?: Theme;
  style?: React.CSSProperties;
}

export const Typewriter: React.FC<TypewriterProps> = ({
  text,
  startFrame = 0,
  charsPerSecond = 30,
  showCursor = true,
  cursorChar = "|",
  fontSize,
  fontFamily,
  color,
  cursorColor,
  theme = defaultTheme,
  style,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const elapsed = Math.max(0, frame - startFrame);
  const charsPerFrame = charsPerSecond / fps;
  const visibleChars = Math.floor(elapsed * charsPerFrame);
  const clampedChars = Math.min(visibleChars, text.length);
  const displayText = text.slice(0, clampedChars);
  const isComplete = clampedChars >= text.length;
  const cursorVisible = showCursor && (!isComplete || Math.sin(frame * 0.15) > 0);

  return (
    <span style={{ fontFamily: fontFamily || theme.fonts.body, fontSize: fontSize || theme.fontSizes.lg, color: color || theme.colors.text, ...style }}>
      {displayText}
      {showCursor && (
        <span style={{ color: cursorColor || theme.colors.primary, opacity: cursorVisible ? 1 : 0 }}>{cursorChar}</span>
      )}
    </span>
  );
};
